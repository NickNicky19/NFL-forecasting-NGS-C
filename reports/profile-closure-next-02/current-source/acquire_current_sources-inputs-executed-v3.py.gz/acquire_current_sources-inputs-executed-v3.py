"""Bounded manual C04 factual-source qualification, with recoverable projections.

No full raw payload, target-game outcomes, sportsbook feed or collector is saved.
"""
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
import argparse,json,hashlib,datetime,gzip,io,re,lzma,csv,sys,zipfile
import pandas as pd
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'src'))
from forward_sources_v4 import team,records,kickoff_frame,native,scoreboard_projection,quarantine_stat_orphans
from context_sources_c01 import COLS,guard
REPORT=ROOT/'reports/profile-closure-next-02/current-source';OUT=ROOT/'sources/profile-closure-next-02'
LIMIT=8;TOTAL=33554432;PER=12582912

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def get(key,url):
 ledger_path=REPORT/'REQUESTS.json';ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else []
 assert len(ledger)<scope_limit(),'CURRENT_SOURCE_REQUEST_CAP'
 assert not any(r['id']==key and r.get('status')==200 for r in ledger),'COMPLETED_SOURCE_FETCH_FROZEN'
 r=dict(id=key,url=url,started_UTC=now(),state='ATTEMPTING');ledger.append(r);write(ledger_path,ledger)
 try:
  with urlopen(Request(url,headers={'User-Agent':'Session-C-manual-C04-source-qualification','Cache-Control':'no-cache','Accept-Encoding':'identity'}),timeout=45) as response:
   body=response.read(PER+1);headers={k.lower():v for k,v in response.headers.items()}
   r.update(status=response.status,bytes=len(body),SHA256=sha(body),observed_UTC=now(),HTTP_Date=headers.get('date'),HTTP_Age=headers.get('age'),HTTP_Last_Modified=headers.get('last-modified'),ETag=headers.get('etag'),state='RECEIVED')
  write(ledger_path,ledger);assert len(body)<=PER,'CURRENT_SOURCE_SINGLE_RESPONSE_CAP';assert sum(x.get('bytes',0) for x in ledger)<=TOTAL,'CURRENT_SOURCE_TOTAL_RESPONSE_CAP'
  return body,r
 except Exception as e:
  r.update(state='FAILED',error=type(e).__name__+':'+str(e),observed_UTC=now(),HTTP_error_status=getattr(e,'code',None),error_body_bytes='NOT_READ');write(ledger_path,ledger);raise

def strip_html(body):
 s=body.decode(errors='replace');s=re.sub(r'<script\b.*?</script>|<style\b.*?</style>',' ',s,flags=re.I|re.S);s=re.sub(r'<[^>]+>',' ',s);return re.sub(r'\s+',' ',s)

def roster():
 assert not (REPORT/'ROSTER_QUALIFICATION.json').exists(),'COMPLETED_ROSTER_QUALIFICATION_FROZEN'
 b,doc=get('CURRENT_ROSTER_DEFINITION','https://nflreadr.nflverse.com/reference/load_rosters.html');s=strip_html(b)
 snippets=[]
 for word in ['current','roster','week','status','season','nflverse','daily']:
  for m in list(re.finditer(re.escape(word),s,re.I))[:5]:snippets.append(s[max(0,m.start()-90):m.start()+360])
 write(REPORT/'CURRENT_ROSTER_DOCUMENTATION.json',dict(source=doc,excerpts=snippets,notes='Definition documentation is not observation of future event participation. Existing data-schedule documentation retained separately states roster daily7AMUTC.'))
 b,source=get('CURRENT_SEASON_ROSTER','https://github.com/nflverse/nflverse-data/releases/download/rosters/roster_2026.csv')
 frame=pd.read_csv(io.BytesIO(b),low_memory=False);columns=frame.columns.tolist()
 needed=['season','team','position','gsis_id','full_name','status'];missing=[c for c in needed if c not in frame]
 if missing:
  write(REPORT/'ROSTER_QUALIFICATION.json',dict(status='SOURCE_BLOCKED',source=source,columns=columns,missing=missing,reason='Required current-roster identity/status fields absent; no guesses or week fabrication.'));return
 frame=frame[frame.season==2026].copy();frame['team']=frame.team.map(team);used=frame[frame.position.isin(['QB','RB','WR','TE'])][needed].copy()
 metadata={'source_contract':'NFLVERSE_SEASON_ROSTER_SNAPSHOT_CURRENT_VINTAGE','source_observed_UTC':source['observed_UTC'],'provider_last_modified_UTC':source['HTTP_Last_Modified'],'original_effective_datetime':'NOT_IN_SOURCE_ROWS;current snapshot meaning assessed separately','week':None,'original_source_has_week':'week' in columns}
 if 'week' in frame:metadata['source_week_values']=sorted(frame.week.dropna().unique().tolist())
 # No gameday healthy/starter inference, and nonACT records remain basic coverage.
 outrows=records(used);(OUT/'roster_current_season.json').write_text(json.dumps(outrows,separators=(',',':'))+'\n')
 counts=used.groupby(['position','status'],dropna=False).size().to_dict();by_status={str(k):int(v) for k,v in counts.items()}
 duplicate=used.gsis_id.notna() & used.duplicated(['gsis_id'],keep=False)
 disposition=dict(id='C04-CURRENT-SEASON-ROSTER-QUALIFICATION-v1',source=source,documentation=doc,metadata=metadata,columns=columns,rows=len(used),all_roles_basic_counts=by_status,duplicate_native_rows=int(duplicate.sum()),duplicate_native_examples=records(used[duplicate][needed].head(12)),status='AWAITING_SEMANTIC_REVIEW',reason='Season/current roster has no declared event-week; never relabel asWeek10. Retain actual source clocks; parent reviews current roster snapshot semantics before forecast admission.',rights='ExistingqualifiedNFLverseordinary factualrosterprojection/CCBY4; noFTN/NGS/odds/privatefields',projection=dict(path=str((OUT/'roster_current_season.json').relative_to(ROOT)),bytes=(OUT/'roster_current_season.json').stat().st_size,SHA256=sha((OUT/'roster_current_season.json').read_bytes())),not_claimed=['Expectedstarter','Confirmedfutureparticipation','Healthy','Authenticatedhistoricalavailability'])
 write(REPORT/'ROSTER_QUALIFICATION.json',disposition);guard();print(json.dumps({k:disposition[k] for k in ['rows','duplicate_native_rows','status']},separators=(',',':')))

def football():
 assert (REPORT/'ROSTER_QUALIFICATION.json').exists(),'ROSTER_FIRST'
 assert not (OUT/'SOURCE_MANIFEST.json').exists(),'COMPLETED_SOURCE_SNAPSHOT_FROZEN'
 b,sm=get('SCHEDULE_CURRENT','https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv');g=kickoff_frame(pd.read_csv(io.BytesIO(b),low_memory=False));cut=pd.Timestamp.now(tz='UTC').timestamp();future=g[(g.season==2026)&(g.game_type=='REG')&(g.kickoff>cut+300)].sort_values(['kickoff','game_id']);assert len(future);game=future.iloc[0];future=future[future.week==int(game.week)].copy();day='20261112-20261116'
 b,em=get('CURRENT_NATIVE_STATUS','https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates='+day+'&limit=100');observed_events=scoreboard_projection(json.loads(b),'CURRENT_NATIVE_STATUS',em['observed_UTC']);event_map={x['espn_event_id']:x for x in observed_events};events=[];excluded=[]
 for record in future.to_dict('records'):
  e=event_map.get(native(record['espn']))
  if e is None:excluded.append(dict(game_id=record['game_id'],reason='NO_NATIVE_STATUS_IN_SNAPSHOT'));continue
  if not (e['state']=='pre' and e['status_name']=='STATUS_SCHEDULED' and not e['completed'] and e['kickoff']>cut and abs(e['kickoff']-record['kickoff'])<1 and {e['home_team'],e['away_team']}=={team(record['home_team']),team(record['away_team'])} and e['season']==2026 and e['season_type']==2 and e['week']==int(record['week'])):
   excluded.append(dict(game_id=record['game_id'],reason='SCHEDULE_STATUS_VERSION_MISMATCH_OR_STARTED'));continue
  e=dict(e,game_id=record['game_id']);e['event_version']=sha(json.dumps({k:e[k] for k in ['game_id','espn_event_id','kickoff_UTC','state']},sort_keys=True).encode());events.append(e)
 assert events,'NO_VERIFIED_FUTURE_EVENTS';e=events[0]
 (OUT/'events.json').write_text(json.dumps(events,indent=2)+'\n');scols=['game_id','season','week','game_type','gameday','gametime','home_team','away_team','home_score','away_score'];g[(g.season==2026)&(g.game_type=='REG')][scols].to_csv(OUT/'schedule.csv',index=False)
 b,tm=get('CURRENT_PLAYER_STATS','https://github.com/nflverse/nflverse-data/releases/download/stats_player/stats_player_week_2026.csv.gz');df=pd.read_csv(io.BytesIO(b),compression='gzip',low_memory=False);df=df[(df.season==2026)&(df.season_type=='REG')].copy();df,orphans=quarantine_stat_orphans(df)
 with zipfile.ZipFile(ROOT/'artifacts/basic-football-facts-v2.1.zip') as z:columns=pd.read_csv(io.BytesIO(z.read('facts.csv.gz')),compression='gzip',nrows=0).columns.tolist()
 assert set(columns)<=set(df),'MISSING_FACT_SCHEMA';assert not df.duplicated(['game_id','player_id']).any();assert not df.game_id.isin([e['game_id'] for e in events]).any(),'FUTURE_TARGET_STATS_NOT_EXPECTED';df[columns].to_csv(OUT/'current_facts_2026.csv.gz',index=False,compression={'method':'gzip','mtime':0})
 b,pm=get('CURRENT_PBP','https://github.com/nflverse/nflverse-data/releases/download/pbp/play_by_play_2026.csv.gz');buffer=io.StringIO();w=csv.DictWriter(buffer,fieldnames=COLS,lineterminator='\n');w.writeheader();count=0;seen=set()
 with gzip.open(io.BytesIO(b),'rt') as f:
  rows=csv.DictReader(f);assert set(COLS)<=set(rows.fieldnames),'PBP_Factual_SCHEMA_MISSING'
  for row in rows:
   if row['season_type']!='REG' or not any(row[c]=='1' for c in ['pass_attempt','rush_attempt','qb_dropback']):continue
   key=(row['game_id'],row['play_id']);assert key not in seen,'DUPLICATE_PBP_PLAY';seen.add(key);w.writerow({k:row[k] for k in COLS});count+=1
 path=OUT/'pbp_facts_2026.csv.xz';path.write_bytes(lzma.compress(buffer.getvalue().encode(),preset=6));assert not any(k[0] in {e['game_id'] for e in events} for k in seen),'FUTURE_TARGET_PLAY_NOT_EXPECTED'
 files=[]
 for name in ['roster_current_season.json','events.json','schedule.csv','current_facts_2026.csv.gz','pbp_facts_2026.csv.xz']:
  p=OUT/name;files.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,SHA256=sha(p.read_bytes())))
 manifest=dict(id='C04-CURRENT-FOOTBALL-SNAPSHOT-v1',information_cutoff_UTC=now(),event=e,events=events,scheduled_future_games=len(future),verified_future_games=len(events),excluded_events=excluded,target_week=int(game.week),roster_week=None,roster_contract='CURRENT_SEASON_SNAPSHOT_NO_EVENT_WEEK_FABRICATED',roster_qualification='reports/profile-closure-next-02/current-source/ROSTER_QUALIFICATION.json',sources=json.loads((REPORT/'REQUESTS.json').read_text()),files=files,quarantined_stat_orphans=orphans,pbp_rows=count,future_target_outcomes_absent=True,source_rights='ExistingnflverseCCBY4ordinaryfactprojection/nativeeventfacts, noFTN/NGS/odds/descriptionorprotectedoutputs',historical_source_vintage='Currentrevisedversion, notbackdatedoriginalhistory',forecast_or_selection_issued=False)
 write(OUT/'SOURCE_MANIFEST.json',manifest);(OUT/'ATTRIBUTION.md').write_text('Ordinary roster/player/play facts: nflverse/nflverse-data, CC BY 4.0, https://creativecommons.org/licenses/by/4.0/; schedule: nflverse/nfldata. Native event facts: public ESPN scoreboard. C retains minimal ordinary factual projections and derives timing/profile inputs. No endorsement, tracking/charting rights, current prop offers or original historical observation timestamps are implied.\n');guard();print('CURRENT_FOOTBALL_READY',game.game_id,e['espn_event_id'],manifest['information_cutoff_UTC'],len(df),count,'verified_games',len(events))


# The original failed roster/range builds above are preserved as gzip members.
# New stages below recover retained inputs before any dependent network step.
def scope_limit():
 amendment=REPORT.parent/'CURRENT_SOURCE_SCOPE_AMENDMENT.json'
 if amendment.exists():
  x=json.loads(amendment.read_text());assert x['original_GET_cap']==8 and x['new_total_GET_cap']==10 and x['response_byte_cap_unchanged']==TOTAL
  return 10
 return 8

def source_rows():return json.loads((REPORT/'REQUESTS.json').read_text())

def candidate_schedule():
 g=kickoff_frame(pd.read_csv(OUT/'schedule.csv',low_memory=False));cut=pd.Timestamp.now(tz='UTC').timestamp()
 future=g[(g.season==2026)&(g.game_type=='REG')&(g.week==10)&(g.kickoff>cut+300)].sort_values(['kickoff','game_id'])
 return g,future

def prepare_inputs():
 assert (REPORT/'ROSTER_QUALIFICATION.json').exists(),'ROSTER_QUALIFICATION_FIRST'
 assert not (OUT/'MODEL_INPUT_MANIFEST.json').exists(),'COMPLETED_CURRENT_INPUTS_FROZEN'
 b,sm=get('SCHEDULE_RECOVERY_CURRENT','https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv')
 g=kickoff_frame(pd.read_csv(io.BytesIO(b),low_memory=False));g=g[(g.season==2026)&(g.game_type=='REG')].copy()
 for key in ['home_team','away_team']:g[key]=g[key].map(team)
 cols=['game_id','season','week','game_type','gameday','gametime','home_team','away_team','home_score','away_score','espn']
 # Persist immediately, before status/stats/PBP can fail. Include native event IDs.
 g[cols].to_csv(OUT/'schedule.csv',index=False)
 future=g[(g.week==10)&(g.kickoff>pd.Timestamp.now(tz='UTC').timestamp()+300)].sort_values(['kickoff','game_id']);assert len(future),'NO_UPCOMING_WEEK10_SCHEDULE'
 proposal=records(future[['game_id','season','week','gameday','gametime','home_team','away_team','espn','kickoff']])
 write(OUT/'candidate_schedule.json',{'status':'SCHEDULE_CANDIDATES_ONLY_NATIVE_STATUS_NOT_YET_VERIFIED','created_UTC':now(),'games':proposal})
 b,tm=get('CURRENT_PLAYER_STATS','https://github.com/nflverse/nflverse-data/releases/download/stats_player/stats_player_week_2026.csv.gz')
 df=pd.read_csv(io.BytesIO(b),compression='gzip',low_memory=False);df=df[(df.season==2026)&(df.season_type=='REG')].copy();df,orphans=quarantine_stat_orphans(df)
 for name in ['team','opponent_team']:df[name]=df[name].map(team)
 with zipfile.ZipFile(ROOT/'artifacts/basic-football-facts-v2.1.zip') as z:cols=pd.read_csv(io.BytesIO(z.read('facts.csv.gz')),compression='gzip',nrows=0).columns.tolist()
 assert set(cols)<=set(df),'MISSING_FACT_SCHEMA';assert not df.duplicated(['game_id','player_id']).any(),'DUPLICATE_NATIVE_PLAYER_EVENT';assert not df.game_id.isin(future.game_id).any(),'FUTURE_TARGET_STATS_NOT_EXPECTED'
 df[cols].to_csv(OUT/'current_facts_2026.csv.gz',index=False,compression={'method':'gzip','mtime':0})
 write(REPORT/'CURRENT_FACT_PROJECTION.json',{'source':tm,'rows':len(df),'used_columns':cols,'quarantined_stat_orphans':orphans,'unknown_fields_not_zero_filled':True})
 b,pm=get('CURRENT_PBP','https://github.com/nflverse/nflverse-data/releases/download/pbp/play_by_play_2026.csv.gz')
 buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=COLS,lineterminator='\n');writer.writeheader();seen=set();count=0;games=set();missing={k:0 for k in COLS}
 with gzip.open(io.BytesIO(b),'rt') as f:
  rows=csv.DictReader(f);assert set(COLS)<=set(rows.fieldnames),'PBP_43_FIELD_SCHEMA_MISSING'
  for row in rows:
   if row['season_type']!='REG' or not any(row[c]=='1' for c in ['pass_attempt','rush_attempt','qb_dropback']):continue
   assert row['season']=='2026';key=(row['game_id'],row['play_id']);assert key not in seen,'DUPLICATE_PBP_PLAY';seen.add(key)
   used={k:row[k] for k in COLS};used['posteam']=team(used['posteam']) if used['posteam'] else '';used['defteam']=team(used['defteam']) if used['defteam'] else '';writer.writerow(used);count+=1;games.add(row['game_id'])
   for k,v in used.items():missing[k]+=v==''
 p=OUT/'pbp_facts_2026.csv.xz';p.write_bytes(lzma.compress(buf.getvalue().encode(),preset=6));assert not games.intersection(set(future.game_id)),'FUTURE_TARGET_PLAY_NOT_EXPECTED'
 write(REPORT/'CURRENT_PBP_PROJECTION.json',{'source':pm,'rows':count,'games':len(games),'used_columns':COLS,'missing':missing,'role':'Ordinary factualcontextprojection, notNGS/charting/alignment/routes','unknown_fields_not_zero_filled':True})
 files=[]
 for name in ['roster_current_season.json','schedule.csv','candidate_schedule.json','current_facts_2026.csv.gz','pbp_facts_2026.csv.xz']:
  p=OUT/name;files.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,SHA256=sha(p.read_bytes())))
 snapshot={'id':'C04-CURRENT-MODEL-INPUTS-v1','actual_input_cutoff_UTC':now(),'roster_contract':'NFLVERSE_CURRENT_KNOWN_SEASON_ROSTER_SNAPSHOT-v1','roster_week':None,'roster_definition_note':'Projectiondoesnotuseafuturegameweek;originalfullheaderpresenceunrecordedafterpreserveddiagnosticfailure','source_observed':{r['id']:r.get('observed_UTC') for r in source_rows() if r.get('status')==200},'sources':source_rows(),'files':files,'target_season':2026,'target_week':10,'tentative_future_games':len(future),'native_event_admission':'PENDING_RESERVED_FINAL_STATUS_GET_AT_ISSUANCE','future_target_outcomes_absent':True,'source_history_vintage':'Currentrevisedhistoricalfacts,notauthenticatedoriginalavailability','roster_qualification':'reports/profile-closure-next-02/current-source/ROSTER_QUALIFICATION.json','fits_or_forecasts_issued':0,'rights':'Existingapprovedordinarynflverse factualprojectionandminimalnativeeventfacts;noodds/privateNGS/FTN/descriptions','failed_schedule_attempt_preserved':'reports/profile-closure-next-02/current-source/FOOTBALL_STAGE_FAILURE.json'}
 write(OUT/'MODEL_INPUT_MANIFEST.json',snapshot)
 (OUT/'ATTRIBUTION.md').write_text('Ordinary roster/player/play facts: nflverse/nflverse-data, CC BY 4.0, https://creativecommons.org/licenses/by/4.0/; schedule: nflverse/nfldata. C projects only needed ordinary factual fields, canonicalizes existing team aliases, and derives profiles/timing sensitivity. Native event status is from the public ESPN scoreboard. Current source observations are recorded; historical versions/individual roster transaction clocks are not backdated. No FTN/NGS tracking, sportsbook data, descriptions or provider presentation is retained.\n')
 guard();print('CURRENT_MODEL_INPUTS_READY',len(future),len(df),count,snapshot['actual_input_cutoff_UTC'])

def refresh_status():
 assert (OUT/'MODEL_INPUT_MANIFEST.json').exists(),'MODEL_INPUTS_REQUIRED'
 assert not (OUT/'SOURCE_MANIFEST.json').exists(),'FINAL_SOURCE_MANIFEST_ALREADY_FROZEN'
 g,future=candidate_schedule();assert len(future),'NO_CURRENT_FUTURE_CANDIDATES'
 url='https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=20261112-20261117&seasontype=2&week=10&year=2026&limit=100'
 try:b,em=get('CURRENT_NATIVE_STATUS_WEEK10_CORRECTED',url)
 except HTTPError as error:
  if error.code not in [400,404]:raise
  b,em=get('CURRENT_NATIVE_STATUS_FIRST_EVENT_FALLBACK','https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=20261112&limit=100')
 payload=json.loads(b);observed=scoreboard_projection(payload,em['id'],em['observed_UTC']);eventmap={e['espn_event_id']:e for e in observed};accepted=[];excluded=[];cut=pd.Timestamp.now(tz='UTC').timestamp()
 for r in future.to_dict('records'):
  e=eventmap.get(native(r['espn']))
  if not e:excluded.append(dict(game_id=r['game_id'],reason='NO_NATIVE_EVENT_IN_FINAL_SNAPSHOT'));continue
  valid=e['season']==2026 and e['season_type']==2 and e['week']==10 and e['state']=='pre' and e['status_name']=='STATUS_SCHEDULED' and e['completed'] is False and e['kickoff']>cut and abs(e['kickoff']-r['kickoff'])<1 and e['home_team']==team(r['home_team']) and e['away_team']==team(r['away_team'])
  if not valid:excluded.append(dict(game_id=r['game_id'],reason='CURRENT_NATIVE_ID_KICKOFF_TEAM_WEEK_STATUS_MISMATCH_OR_STARTED'));continue
  e=dict(e,game_id=r['game_id']);e['event_version']=sha(json.dumps({k:e[k] for k in ['game_id','espn_event_id','kickoff_UTC','state']},sort_keys=True).encode());accepted.append(e)
 assert accepted,'NO_NATIVE_VERIFIED_UPCOMING_EVENT'
 write(OUT/'events.json',accepted)
 prior=(OUT/'MODEL_INPUT_MANIFEST.json').read_bytes();roster=json.loads((REPORT/'ROSTER_QUALIFICATION.json').read_text());manifest={'id':'C04-CURRENT-SOURCE-ADMISSION-v1','actual_status_observed_UTC':em['observed_UTC'],'actual_admission_UTC':now(),'model_inputs':{'path':str((OUT/'MODEL_INPUT_MANIFEST.json').relative_to(ROOT)),'SHA256':sha(prior),'input_cutoff_UTC':json.loads(prior)['actual_input_cutoff_UTC']},'events':accepted,'event':accepted[0],'target_season':2026,'target_week':10,'roster_source_week':None,'roster_contract':roster['source_contract'],'roster_qualification':{'path':str((REPORT/'ROSTER_QUALIFICATION.json').relative_to(ROOT)),'SHA256':sha((REPORT/'ROSTER_QUALIFICATION.json').read_bytes())},'scheduled_candidate_games':len(future),'verified_future_games':len(accepted),'excluded_events':excluded,'sources':source_rows(),'source_observed':{r['id']:r.get('observed_UTC') for r in source_rows() if r.get('status')==200},'forecasts_or_selections_issued':0,'scope':'Currentknownrosterqueryadmission,conditionalonappearance;nostarter/healthy/futuregamedayguarantee','final_status_age_rule':'Actualissuanceadaptermustcheckstatusage<=1800secondsandkickoffstillfuture;thisfileisnotpermanentavailability','current_offers':0,'source_rights':'Existingordinarynflverse facts/CCBY4 andminimalnativeeventfacts;nooffercollection'}
 write(OUT/'SOURCE_MANIFEST.json',manifest);guard();print('CURRENT_NATIVE_STATUS_READY',len(accepted),'of',len(future),em['observed_UTC'])

if __name__=='__main__':
 REPORT.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['roster','prepare_inputs','refresh_status'],required=True);a=p.parse_args()
 {'roster':roster,'prepare_inputs':prepare_inputs,'refresh_status':refresh_status}[a.stage]()
