"""Execution wrapper: retain a data profile from the already-needed preparation.

This does not alter the fitting matrices, labels, cohorts or model code. The
snapshot is reconstructed as-of data, never a new forecast or live issuance.
"""
import argparse,hashlib,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src'))
import receiving_increment_c03 as model
original=model.prepare

def prepare_with_snapshot():
 result=original();defense=result[5];cut=model.now()
 rows=defense.snapshot(cut)
 dest=model.OUT/f'DEFENSE_SNAPSHOT-{cut[:10]}.json.xz'
 if not dest.exists():
  model.write(dest,{'id':'C-RECEIVING-DEFENSE-ASOF-DATA-v1','actual_creation_UTC':cut,'profiles':rows,'profile_count':len(rows),'forecast_or_selection_capture':False,'source_scope':'Frozen qualified2024-2026current-vintage reconstruction; strictkickoff+7day; not freshroster/authenticatedhistoricalvintage','wrapper_SHA256':model.sha(Path(__file__))})
  model.write(model.OUT/'DEFENSE_SNAPSHOT_INDEX.json',{'path':str(dest.relative_to(ROOT)),'SHA256':model.sha(dest),'profile_count':len(rows),'teams':[{'team':r['team'],'state':r['state'],'eligible_games':r['eligible_games'],'latest_source_game':r['latest_source_game']} for r in rows],'actual_creation_UTC':cut,'new_predictions':0})
 return result

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--year',type=int,choices=[2025,2026],default=2026);a=parser.parse_args()
 model.prepare=prepare_with_snapshot
 model.run(a.year,False)
