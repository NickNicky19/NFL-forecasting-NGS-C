from pathlib import Path
from urllib.request import Request,urlopen
import sys,json,io,gzip,hashlib,datetime,re
import pandas as pd
root=Path('/workspace/ngs-c');sys.path.insert(0,str(root/'src'));from forward_sources_v4 import kickoff_frame,scoreboard_projection,native,team,records
out=root/'sources/profile-increment-v2';report=root/'reports/profile-increment-v2';ledger=[]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def get(key,url,cap):
 assert len(ledger)<4
 r={'id':key,'url':url,'started_UTC':now()};ledger.append(r);(report/'SOURCE_REQUESTS.json').write_text(json.dumps(ledger,indent=2)+'\n')
 with urlopen(Request(url,headers={'User-Agent':'C-manual-profile-increment-v2','Cache-Control':'no-cache'}),timeout=40) as f:b=f.read(cap+1);h={k.lower():v for k,v in f.headers.items()};assert len(b)<=cap;r.update(status=f.status,bytes=len(b),SHA256=hashlib.sha256(b).hexdigest(),observed_UTC=now(),Date=h.get('date'),Last_Modified=h.get('last-modified'),ETag=h.get('etag'))
 assert sum(x.get('bytes',0) for x in ledger)<=4194304
 (report/'SOURCE_REQUESTS.json').write_text(json.dumps(ledger,indent=2)+'\n');return b,r
b,doc=get('ROSTER_DEFINITION','https://nflreadr.nflverse.com/reference/load_rosters_weekly.html',256000)
s=re.sub('<[^>]+>',' ',b.decode(errors='replace'));s=re.sub(r'\s+',' ',s);excerpts=[]
for word in ['week','Tuesday','update','depth','roster']:
 for m in list(re.finditer(word,s,re.I))[:5]:excerpts.append(s[max(0,m.start()-100):m.start()+340])
(report/'ROSTER_SEMANTICS.json').write_text(json.dumps({'source':doc,'excerpts':excerpts,'disposition':'Week label identifies rosterweek; documentationalone doesnot establishfutureevent-effective coverage. No automaticrelabeling orstarterclaim.'},indent=2)+'\n')
b,sm=get('SCHEDULE_CURRENT','https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv',2500000);g=kickoff_frame(pd.read_csv(io.BytesIO(b),low_memory=False));future=g[(g.season==2026)&(g.game_type=='REG')&(g.kickoff>pd.Timestamp.now(tz='UTC').timestamp()+300)].sort_values(['kickoff','game_id']);assert len(future);game=future.iloc[0];day=pd.Timestamp(game.kickoff,unit='s',tz='UTC').tz_convert('America/New_York').strftime('%Y%m%d')
b,em=get('STATUS_CURRENT','https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates='+day+'&limit=100',200000);events=scoreboard_projection(json.loads(b),'STATUS_CURRENT',em['observed_UTC']);e=next(x for x in events if x['espn_event_id']==native(game.espn));assert e['state']=='pre' and not e['completed'] and abs(e['kickoff']-game.kickoff)<1;e['game_id']=game.game_id
b,rm=get('ROSTER_CURRENT','https://github.com/nflverse/nflverse-data/releases/download/weekly_rosters/roster_weekly_2026.csv.gz',1000000);r=pd.read_csv(io.BytesIO(b),compression='gzip',low_memory=False);r=r[(r.season==2026)&(r.week<=int(game.week))&r.team.map(team).isin([e['home_team'],e['away_team']])&r.position.isin(['QB','RB','WR','TE'])].copy();week=int(r.week.max());r=r[r.week==week][['season','week','team','gsis_id','full_name','position','status','depth_chart_position']];r['team']=r.team.map(team)
(out/'roster.json').write_text(json.dumps(records(r),separators=(',',':'))+'\n');(out/'events.json').write_text(json.dumps([e],indent=2)+'\n');g[(g.season==2026)&(g.game_type=='REG')][['game_id','season','week','game_type','gameday','gametime','home_team','away_team','home_score','away_score']].to_csv(out/'schedule.csv',index=False)
manifest={'id':'C-PROFILE-INCREMENT-CURRENT-SOURCE-v2','cutoff_UTC':now(),'event':e,'target_week':int(game.week),'roster_week':week,'roster_rows':len(r),'sources':ledger,'raw_roster_same_as_prior':rm['SHA256']=='8b7d5cdc6627422392e24cfee796232f33e2e745731e124c691a43a0292c8087','roster_status':'EXACT_WEEK_OBSERVATION_NOT_STARTER_CONFIRMATION' if week==int(game.week) else 'EVENT_EFFECTIVE_ROSTER_NOT_ESTABLISHED;PRIOR_WEEK_NOT_RELABELLED','forecasts':0,'selections':0,'rights':'ExistingordinarynflverseCCBY4 factualprojection/nativeeventstatuspermitted. Nooffers/NGS/FTN/paiddata.'}
(out/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k] for k in ['cutoff_UTC','target_week','roster_week','roster_rows','raw_roster_same_as_prior','roster_status']}))
