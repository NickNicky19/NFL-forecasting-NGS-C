from playwright.sync_api import sync_playwright
from pathlib import Path
import json,datetime,hashlib,subprocess,sys
root=Path('/workspace/ngs-c');url=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8765/context.html';public=url.startswith('https://');data=json.loads((root/'docs/data/profile-increment-v2.json').read_text());receipts=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [1440,390]:
  page=browser.new_page(viewport={'width':width,'height':900});errors=[];page.on('pageerror',lambda x:errors.append(str(x)));response=page.goto(url);page.wait_for_function('document.querySelectorAll("#profile-increment-actual tr").length===18');page.wait_for_function('document.querySelectorAll("#actual tr").length>0')
  for row in data['actual_scores']:
   tr=page.locator(f'#profile-increment-actual tr[data-method="{row["method"]}"]');cells=tr.locator('td').all_text_contents();c=row['COMBINED'];expected=f'{c["wins"]}–{c["losses"]}/{c["decided"]}/{100*c["rate"]:.2f}%';assert cells[3]==expected
   if row['method'].endswith(('_MEAN','_MEDIAN')):assert cells[-1]=='N/A'
  assert page.locator('#profile-increment-numerical tr').count()==8;assert page.locator('#profile-increment-paired tr').count()==10
  current=page.locator('#profile-increment-current').inner_text();assert '53 basic' in current and '35 receiving-priority' in current and '32 defense' in current and 'CST' in current and '5:45:06' in current
  old=page.locator('#actual tr').count();page.select_option('#scope','RB');assert page.locator('#actual tr').count()>0 and page.locator('#profile-increment-actual tr').count()==18
  overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth');assert not overflow,('mobileoverflow',width)
  assert not errors;receipts.append({'viewport':width,'HTTP':response.status,'actual_rows':18,'numerical_rows':8,'paired_rows':10,'exact_rendered_records':True,'Chicago_DST':'CST Nov10 5:45:06','old_role_filter_independent':True,'page_errors':errors,'body_overflow':overflow});page.close()
 if not public:
  page=browser.new_page();page.route('**/data/profile-increment-v2.json',lambda route:route.fulfill(status=503,body='unavailable'));page.goto(url);page.wait_for_function('document.querySelector("#profile-increment-status").textContent.startsWith("Completed comparison unavailable")');page.wait_for_function('document.querySelectorAll("#actual tr").length>0');assert page.locator('#profile-increment-actual tr').count()==0;receipts.append({'failure':'newpayload503','fail_closed':True,'old_study_preserved':True});page.close()
  page=browser.new_page();page.route('**/data/context-matchup-v1.json',lambda route:route.fulfill(status=503,body='unavailable'));page.goto(url);page.wait_for_function('document.querySelectorAll("#profile-increment-actual tr").length===18');assert page.locator('#actual tr').count()==0;receipts.append({'failure':'oldpayload503','new_study_independent':True});page.close()
  page=browser.new_page()
  oldhtml=subprocess.check_output(['git','show','06da9bb:docs/context.html'],cwd=root);oldjs=subprocess.check_output(['git','show','06da9bb:docs/context.js'],cwd=root)
  page.route('**/context.html',lambda route:route.fulfill(status=200,content_type='text/html',body=oldhtml));page.route('**/context.js',lambda route:route.fulfill(status=200,content_type='application/javascript',body=oldjs));page.goto(url);page.wait_for_function('document.querySelectorAll("#actual tr").length>0');assert page.locator('#profile-increment-actual').count()==0;receipts.append({'rollback_source':'06da9bb','old_HTML_JS_preview':'PASS','deployed_rollback':False});page.close()
 browser.close()
out={'id':'C-C03-PUBLIC-SERVED-QA-v1' if public else 'C-C03-LOCAL-BROWSER-QA-v1','actual_observed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'URL':url,'checks':receipts,'data_SHA256':hashlib.sha256((root/'docs/data/profile-increment-v2.json').read_bytes()).hexdigest(),'only_C_research_results_published':True,'forecast_or_policy_release':False,'original_site_browser_or_payload_consumption_verified':False}
path=root/'reports/profile-increment-v2'/('SERVED_BROWSER_QA.json' if public else 'LOCAL_BROWSER_QA.json');path.write_text(json.dumps(out,indent=2)+'\n');print('BROWSER_QA_PASS',url,len(receipts))
